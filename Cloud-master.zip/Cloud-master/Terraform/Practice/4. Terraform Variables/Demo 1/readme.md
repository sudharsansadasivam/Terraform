#Different Methods to Use Variables in terraform
