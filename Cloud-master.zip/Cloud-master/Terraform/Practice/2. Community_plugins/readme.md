### Community Plugins 


| Operating System | User Plugin Directory |
| ------ | ------ |
| Windows | %APPDATA%\terraform.d\plugins  |
| All Other Systems  |~/.terraform.d/plugins |
